#include <iostream>
#include <cmath>       
#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>

const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;


const char* vertexShaderSource = "#version 330 core\n"
"layout (location = 0) in vec3 aPos;\n"        
"layout (location = 1) in vec3 aColor;\n"   
"out vec3 ourColor;\n"                        
"void main()\n"
"{\n"
"   gl_Position = vec4(aPos, 1.0);\n"       
"   ourColor = aColor;\n"
"}\n";

const char* fragmentShaderSource = "#version 330 core\n"
"out vec4 FragColor;\n"
"in vec3 ourColor;\n"
"uniform float uAlpha;\n"                      
"void main()\n"
"{\n"
"   FragColor = vec4(ourColor, uAlpha);\n"    
"}\n";

void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    else
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

void generateCircle(float* vertices, int numSegments, float radius, float centerX, float centerY, float r, float g, float b)
{
    for (int i = 0; i < numSegments; ++i)
    {
        float theta = 2.0f * 3.1415926f * float(i) / float(numSegments);
        float x = centerX + radius * cosf(theta);
        float y = centerY + radius * sinf(theta);
        vertices[i * 6 + 0] = x;
        vertices[i * 6 + 1] = y;
        vertices[i * 6 + 2] = 0.0f;  
        vertices[i * 6 + 3] = r;
        vertices[i * 6 + 4] = g;
        vertices[i * 6 + 5] = b;
    }
}

int main()
{
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "OpenGL Scene: Sun & Tree", NULL, NULL);
    if (window == NULL) { glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) { std::cout << "Failed to initialize GLEW" << std::endl; return -1; }

    glEnable(GL_DEPTH_TEST);                       
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 

    unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);

    unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);

    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);


    float grassVertices[] = {

        -1.0f, -1.0f, 0.0f,   0.0f, 0.6f, 0.0f, 
         1.0f, -1.0f, 0.0f,   0.0f, 0.6f, 0.0f,  
         1.0f, -0.5f, 0.0f,   0.0f, 0.6f, 0.0f,  
         -1.0f, -0.5f, 0.0f,   0.0f, 0.6f, 0.0f   
    };
    unsigned int grassIndices[] = { 0, 1, 2, 2, 3, 0 };
    unsigned int grassVAO, grassVBO, grassEBO;
    glGenVertexArrays(1, &grassVAO);
    glGenBuffers(1, &grassVBO);
    glGenBuffers(1, &grassEBO);
    glBindVertexArray(grassVAO);
    glBindBuffer(GL_ARRAY_BUFFER, grassVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(grassVertices), grassVertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, grassEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(grassIndices), grassIndices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

  
    float trunkVertices[] = {
        -0.05f, -0.5f, 0.0f,   0.55f, 0.27f, 0.07f,
         0.05f, -0.5f, 0.0f,   0.55f, 0.27f, 0.07f,
         0.05f,  0.0f, 0.0f,   0.55f, 0.27f, 0.07f,
        -0.05f,  0.0f, 0.0f,   0.55f, 0.27f, 0.07f
    };
    unsigned int trunkIndices[] = { 0,1,2, 2,3,0 };
    unsigned int trunkVAO, trunkVBO, trunkEBO;
    glGenVertexArrays(1, &trunkVAO);
    glGenBuffers(1, &trunkVBO);
    glGenBuffers(1, &trunkEBO);
    glBindVertexArray(trunkVAO);
    glBindBuffer(GL_ARRAY_BUFFER, trunkVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(trunkVertices), trunkVertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, trunkEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(trunkIndices), trunkIndices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // أوراق مثلث
    float leavesVertices[] = {
        -0.2f, 0.0f, 0.0f,  0.0f, 0.8f, 0.0f,
         0.2f, 0.0f, 0.0f,  0.0f, 0.8f, 0.0f,
         0.0f, 0.4f, 0.0f,  0.0f, 0.8f, 0.0f
    };
    unsigned int leavesVAO, leavesVBO;
    glGenVertexArrays(1, &leavesVAO);
    glGenBuffers(1, &leavesVBO);
    glBindVertexArray(leavesVAO);
    glBindBuffer(GL_ARRAY_BUFFER, leavesVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(leavesVertices), leavesVertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

 
    float cloudVertices[] = {
        -0.3f, 0.6f, 0.0f,  1.0f,1.0f,1.0f,
         0.3f, 0.6f, 0.0f,  1.0f,1.0f,1.0f,
         0.3f, 0.7f, 0.0f,  1.0f,1.0f,1.0f,
        -0.3f, 0.7f, 0.0f,  1.0f,1.0f,1.0f
    };
    unsigned int cloudIndices[] = { 0,1,2, 2,3,0 };
    unsigned int cloudVAO, cloudVBO, cloudEBO;
    glGenVertexArrays(1, &cloudVAO);
    glGenBuffers(1, &cloudVBO);
    glGenBuffers(1, &cloudEBO);
    glBindVertexArray(cloudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, cloudVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cloudVertices), cloudVertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cloudEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cloudIndices), cloudIndices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

   
    const int sunSegments = 50;                    
    float sunVertices[sunSegments * 6];
    generateCircle(sunVertices, sunSegments, 0.1f, -1.0f, 0.8f, 1.0f, 0.5f, 0.0f); 
    unsigned int sunVAO, sunVBO;
    glGenVertexArrays(1, &sunVAO);
    glGenBuffers(1, &sunVBO);
    glBindVertexArray(sunVAO);
    glBindBuffer(GL_ARRAY_BUFFER, sunVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(sunVertices), sunVertices, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    double startTime = glfwGetTime();
    while (!glfwWindowShouldClose(window))
    {
        processInput(window);

        glClearColor(0.53f, 0.81f, 0.92f, 1.0f); 
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUseProgram(shaderProgram);

        int alphaLoc = glGetUniformLocation(shaderProgram, "uAlpha");

        glBindVertexArray(grassVAO);
        glUniform1f(alphaLoc, 1.0f);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

    
        glBindVertexArray(trunkVAO);
        glUniform1f(alphaLoc, 1.0f);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        glBindVertexArray(leavesVAO);
        glUniform1f(alphaLoc, 1.0f);
        glDrawArrays(GL_TRIANGLES, 0, 3);

      
        glBindVertexArray(cloudVAO);
        glUniform1f(alphaLoc, 0.5f);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

 
        double currentTime = glfwGetTime();
        float t = float(currentTime - startTime);
        float sunX = -1.0f + 2.0f * (t / 7.0f); 

        if (sunX > 1.0f) { startTime = currentTime; sunX = -1.0f; } 

        generateCircle(sunVertices, sunSegments, 0.1f, sunX, 0.8f, 1.0f, 0.5f, 0.0f);
        glBindBuffer(GL_ARRAY_BUFFER, sunVBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(sunVertices), sunVertices);

        glBindVertexArray(sunVAO);
        glUniform1f(alphaLoc, 1.0f);
        glDrawArrays(GL_TRIANGLE_FAN, 0, sunSegments);


        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &grassVAO);
    glDeleteBuffers(1, &grassVBO);
    glDeleteBuffers(1, &grassEBO);

    glDeleteVertexArrays(1, &trunkVAO);
    glDeleteBuffers(1, &trunkVBO);
    glDeleteBuffers(1, &trunkEBO);

    glDeleteVertexArrays(1, &leavesVAO);
    glDeleteBuffers(1, &leavesVBO);

    glDeleteVertexArrays(1, &cloudVAO);
    glDeleteBuffers(1, &cloudVBO);
    glDeleteBuffers(1, &cloudEBO);

    glDeleteVertexArrays(1, &sunVAO);
    glDeleteBuffers(1, &sunVBO);

    glDeleteProgram(shaderProgram);

    glfwTerminate();
    return 0;
}